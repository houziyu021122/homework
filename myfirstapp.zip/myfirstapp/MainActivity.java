package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private RadioButton radioButton1;
    private RadioButton radioButton2;
    private CheckBox checkBox;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch aSwitch;
    private Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout linearLayout = null;
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);

        editText = findViewById(R.id.editText);
        radioButton1 = findViewById(R.id.radioButton1);
        radioButton2 = findViewById(R.id.radioButton2);
        checkBox = findViewById(R.id.checkBox);
        aSwitch = findViewById(R.id.switch1);
        spinner = findViewById(R.id.spinner);
        Button button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = editText.getText().toString();
                boolean radioButton1Selected = radioButton1.isChecked();
                boolean radioButton2Selected = radioButton2.isChecked();
                boolean checkBoxSelected = checkBox.isChecked();
                boolean switchSelected = aSwitch.isChecked();
                String spinnerValue = spinner.getSelectedItem().toString();

                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("text", text);
                intent.putExtra("radioButton1", radioButton1Selected);
                intent.putExtra("radioButton2", radioButton2Selected);
                intent.putExtra("checkBox", checkBoxSelected);
                intent.putExtra("switch", switchSelected);
                intent.putExtra("spinner", spinnerValue);
                startActivity(intent);
            }
        });
    }
}
