package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.text.BreakIterator;

public class SecondActivity extends AppCompatActivity 
{  protected void onCreate(Bundle savedInstanceState) 
    { super.onCreate(savedInstanceState); setContentView(R.layout.activity_second); // 设置布局文件 // 获取TextView引用 TextView textView = findViewById(R.id.textView); // 设置文本内容 textView.setText("This is a new text!");

        // Retrieve the data passed from MainActivity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String text = extras.getString("text");
            boolean radioButton1Selected = extras.getBoolean("radioButton1");
            boolean radioButton2Selected = extras.getBoolean("radioButton2");
            boolean checkBoxSelected = extras.getBoolean("checkBox");
            boolean switchSelected = extras.getBoolean("switch");
            String spinnerValue = extras.getString("spinner");

            // Display the data in the TextView
            BreakIterator textView = null;
            textView.setText("Text: " + text + "\n" + "RadioButton1: " + radioButton1Selected + "\n" +
                    "RadioButton2: " + radioButton2Selected + "\n" +
                    "CheckBox: " + checkBoxSelected + "\n" +
                    "Switch: " + switchSelected + "\n" +
                    "Spinner: " + spinnerValue);
        }
    }
}